
document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();
  const response = document.getElementById("response");

  if (!email || !message) {
    response.textContent = "Please fill in both fields.";
    response.style.color = "red";
  } else {
    response.textContent = "Thank you for reaching out!";
    response.style.color = "lightgreen";
    this.reset();
  }
});
